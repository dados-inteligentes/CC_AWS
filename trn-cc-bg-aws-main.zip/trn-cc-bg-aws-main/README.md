# Big Data na AWS

Este repositório contém o material utilizado no treinamento "Big Data na AWS", que tem como objetivo apresentar e explorar as principais tecnologias de big data oferecidas pela Amazon Web Services (AWS). 

![roadmap.png](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/docs/roadmap.png)




## Estrutura do Repositório

O repositório está organizado da seguinte forma:

- [**aula-01**](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/aula-01)
  - **RDS:** Introdução ao Amazon Relational Database Service (RDS), um serviço gerenciado de banco de dados relacional na nuvem.
  - **S3:** Exploração do Amazon Simple Storage Service (S3), um serviço de armazenamento de objetos escalável e seguro.

- [**aula-02**](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/aula-02)
  - **Kinesis:** Demonstração do Amazon Kinesis, uma plataforma para processamento em tempo real de grandes fluxos de dados.

- [**aula-03**](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/aula-03)
  - **Glue:** Apresentação do AWS Glue, um serviço de ETL (Extract, Transform, Load) gerenciado que facilita a preparação e transformação de dados.
  - **Lambda:** Introdução ao AWS Lambda, um serviço que permite executar código sem provisionar ou gerenciar servidores.
  - **SQS:** Exploração do Amazon Simple Queue Service (SQS), um serviço gerenciado de filas de mensagens.

- [**aula-04**](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/aula-04)
  - **Jar:** Arquivo(s) jar utilizado(s) no treinamento.

- [**docs:**](https://github.com/owshq-academy/trn-cc-bg-aws/blob/main/docs) PPTs usados no treinamento.

## Objetivo do Treinamento

O treinamento "Big Data na AWS" tem como foco capacitar profissionais para utilizarem as tecnologias de big data mais utilizadas na nuvem AWS, oferecendo uma visão prática e teórica sobre como implementar soluções eficientes e escaláveis.